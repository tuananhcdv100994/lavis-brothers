import React, { useState, useCallback } from 'react';
import { Message, Role, CustomerInfo } from './types';
import { getBotResponse } from './services/geminiService';
import ChatInterface from './components/ChatInterface';
import CustomerInfoPanel from './components/CustomerInfoPanel';

function App() {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: Role.MODEL,
      parts: [{ text: 'Xin chào! Tôi là Chat Lavis AI, trợ lý ảo của Lavis Brothers Coating. Tôi có thể giúp gì cho bạn về các giải pháp sơn công nghiệp? 🎨' }],
      id: 'initial-message'
    }
  ]);
  const [customerInfo, setCustomerInfo] = useState<CustomerInfo>({ name: '', phone: '' });
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const handleSendMessage = useCallback(async (userInput: string) => {
    if (!userInput.trim()) return;

    const userMessage: Message = {
      role: Role.USER,
      parts: [{ text: userInput }],
      id: `user-${Date.now()}`
    };
    setMessages(prevMessages => [...prevMessages, userMessage]);
    setIsLoading(true);

    try {
      // Knowledge is now hardcoded in geminiService
      const { responseText, extractedInfo, sources } = await getBotResponse(userInput, messages);
      
      let botResponseText = responseText;
      if (sources && sources.length > 0) {
        const sourceList = sources.map(source => `*   [${source.title}](${source.uri})`).join('\n');
        botResponseText += `\n\n---\n**Nguồn tham khảo:**\n${sourceList}`;
      }

      const botMessage: Message = {
        role: Role.MODEL,
        parts: [{ text: botResponseText }],
        id: `bot-${Date.now()}`
      };
      setMessages(prevMessages => [...prevMessages, botMessage]);

      if (extractedInfo?.name || extractedInfo?.phone) {
        setCustomerInfo(prevInfo => ({
          name: extractedInfo.name || prevInfo.name,
          phone: extractedInfo.phone || prevInfo.phone,
        }));
      }

    } catch (error) {
      console.error("Error getting bot response:", error);
      const errorMessage: Message = {
        role: Role.MODEL,
        parts: [{ text: 'Xin lỗi, tôi không thể kết nối đến máy chủ. Vui lòng kiểm tra lại cấu hình và thử lại sau. 🤖' }],
        id: `error-${Date.now()}`
      };
      setMessages(prevMessages => [...prevMessages, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  }, [messages]);

  return (
    <div className="flex h-screen font-sans text-gray-200 bg-[#0d1a38]">
      <div className="w-96 flex-shrink-0 flex flex-col p-4 space-y-4 bg-[#1a2c58]/50 border-r border-blue-900/50">
        <h1 className="text-2xl font-bold text-center text-blue-300">Lavis Chat AI</h1>
        <CustomerInfoPanel customerInfo={customerInfo} />
      </div>
      <div className="flex-1 flex flex-col bg-[#11224a]">
        <ChatInterface
          messages={messages}
          onSendMessage={handleSendMessage}
          isLoading={isLoading}
        />
        <footer className="text-center p-2 text-xs text-gray-400 bg-transparent">
          Chatbot Lavis Brothers Coating by Plugai.top
        </footer>
      </div>
    </div>
  );
}

export default App;