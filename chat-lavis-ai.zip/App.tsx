import React, { useState, useCallback } from 'react';
import { Message, Role, CustomerInfo } from './types';
import { getBotResponse } from './services/geminiService';
import ChatInterface from './components/ChatInterface';
import CustomerInfoPanel from './components/CustomerInfoPanel';

function App() {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: Role.MODEL,
      parts: [{ text: 'Xin chào! Tôi là Chat Lavis AI, trợ lý ảo của Lavis Brothers Coating. Tôi có thể giúp gì cho bạn về các giải pháp sơn công nghiệp? 🎨' }],
      id: 'initial-message'
    }
  ]);
  const [customerInfo, setCustomerInfo] = useState<CustomerInfo>({ name: '', phone: '' });
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const handleSendMessage = useCallback(async (userInput: string) => {
    if (!userInput.trim()) return;

    const userMessage: Message = {
      role: Role.USER,
      parts: [{ text: userInput }],
      id: `user-${Date.now()}`
    };
    setMessages(prevMessages => [...prevMessages, userMessage]);
    setIsLoading(true);

    try {
      // Knowledge is now hardcoded in geminiService
      const { responseText, extractedInfo, sources } = await getBotResponse(userInput, messages);
      
      let botResponseText = responseText;
      if (sources && sources.length > 0) {
        const sourceList = sources.map(source => `*   [${source.title}](${source.uri})`).join('\n');
        botResponseText += `\n\n---\n**Nguồn tham khảo:**\n${sourceList}`;
      }

      const botMessage: Message = {
        role: Role.MODEL,
        parts: [{ text: botResponseText }],
        id: `bot-${Date.now()}`
      };
      setMessages(prevMessages => [...prevMessages, botMessage]);

      if (extractedInfo?.name || extractedInfo?.phone) {
        setCustomerInfo(prevInfo => ({
          name: extractedInfo.name || prevInfo.name,
          phone: extractedInfo.phone || prevInfo.phone,
        }));
      }

    } catch (error) {
      console.error("Error getting bot response:", error);
      const errorMessage: Message = {
        role: Role.MODEL,
        parts: [{ text: 'Xin lỗi, tôi đang gặp sự cố. Vui lòng thử lại sau. 🤖' }],
        id: `error-${Date.now()}`
      };
      setMessages(prevMessages => [...prevMessages, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  }, [messages]);

  return (
    <div className="flex h-screen font-sans text-gray-800 dark:text-gray-200 bg-slate-100 dark:bg-slate-900">
      <div className="w-96 flex-shrink-0 flex flex-col p-4 space-y-4 bg-white dark:bg-slate-800 border-r border-gray-200 dark:border-slate-700">
        <h1 className="text-2xl font-bold text-center text-blue-600 dark:text-blue-400">Lavis Chat AI</h1>
        <CustomerInfoPanel customerInfo={customerInfo} />
      </div>
      <div className="flex-1 flex flex-col">
        <ChatInterface
          messages={messages}
          onSendMessage={handleSendMessage}
          isLoading={isLoading}
        />
        <footer className="text-center p-2 text-xs text-gray-500 dark:text-gray-400 bg-slate-100 dark:bg-slate-900">
          Chatbot Lavis Brothers Coating by Plugai.top
        </footer>
      </div>
    </div>
  );
}

export default App;