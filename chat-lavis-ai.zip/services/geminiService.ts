import { GoogleGenAI } from '@google/genai';
import { Message, Role, GroundingSource } from '../types';

if (!process.env.API_KEY) {
    throw new Error("API Key is missing. Please set the API_KEY environment variable.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const KNOWLEDGE_BASE = `
# TỔNG HỢP THÔNG TIN VỀ CÔNG TY LAVIS BROTHERS COATING

## 1. THÔNG TIN CÔNG TY
- **Tên công ty**: Lavis Brothers Coating
- **Lĩnh vực**: Sản xuất và cung cấp giải pháp sơn công nghiệp chuyên biệt.
- **Tầm nhìn**: Phát triển các giải pháp sơn bền vững – tối ưu – thân thiện môi trường.
- **Địa chỉ**: Số 16A VSIP II-A, Hòa Bình, Vĩnh Tân, TP. Hồ Chí Minh, Việt Nam.
- **Số điện thoại**: 0274.222.1292 hoặc 0911.46.2292
- **Email**: info@lavisbrothers.com
- **Website**: https://coating.lavisbrothers.com
- **Chứng nhận**: ISO 9001:2015, ISO 14001:2015
- **Đối tác lớn**: NovaWorld, Perfetti Van Melle, Trần Anh Group, Sun Group, Masterise, Kim Oanh, DIC, Bcons.

## 2. GIẢI PHÁP SẢN PHẨM
| Tên sản phẩm | Thành phần / Giải pháp | Công dụng chính | Ứng dụng | Đặc điểm nổi bật |
| :--- | :--- | :--- | :--- | :--- |
| **Roof Expert** | Sơn chống nóng mái tôn + sơn lót chống rỉ | Kéo dài tuổi thọ mái tôn thêm 10 năm, giảm nhiệt độ nhà máy, tiết kiệm điện năng | Nhà máy sản xuất, nhà xưởng, khu công nghiệp | Gốc nước, chỉ số truyền nhiệt thấp (0.445), bám dính vượt trội |
| **Metal Expert** | Sơn bảo vệ bề mặt kim loại | Chống ăn mòn, chống oxy hóa, chịu môi trường khắc nghiệt | Kết cấu thép, công trình công nghiệp | Gốc nước, đạt tiêu chuẩn quốc tế, độ bền cao |
| **Decor Expert** | Sơn trang trí nội ngoại thất | Mang lại hiệu ứng thẩm mỹ cao, phù hợp biệt thự, resort | Biệt thự, dự án cao cấp, nhà dân | Gồm sơn hiệu ứng, sơn gai, sơn đa sắc, bộ Masterpiece |
| **Floor Expert** | Sơn sàn công nghiệp | Chịu lực, chống mài mòn, phù hợp nhà máy, kho xưởng | Khu công nghiệp, kho bãi | Khô nhanh, chống trượt, bền màu |
| **Aqua Expert** | Chống thấm toàn diện | Ngăn nước, che vết nứt nhỏ, bám dính tốt | Sàn, trần, phòng tắm, tầng hầm | Chống nước hiệu quả, thích hợp cả trong nhà & ngoài trời |
| **Road Expert** | Sơn giao thông | Vạch kẻ đường, sân bay, bãi đỗ xe, chịu mài mòn cao | Công trình giao thông | Gốc nước, khô nhanh, bám chắc |
| **Marine Expert** | Sơn cho vật liệu gốm, composite, tàu biển | Bám dính tốt, độ bền cao, nhiều màu | Gốm sứ, composite, công trình biển | An toàn, đạt tiêu chuẩn quốc tế |

## 3. THÔNG TIN KHÁC
- **Thế mạnh công nghệ**: Công nghệ sơn gốc nước bền gấp 3 lần, thân thiện môi trường, và cung cấp giải pháp chuyên biệt cho từng loại bề mặt.
- **Thị trường chính**: Nhà máy công nghiệp, khu công nghiệp, biệt thự, dự án dân dụng, hạ tầng giao thông, và xuất khẩu sang EU/Asia.
- **Định hướng phát triển**: Tăng tỷ trọng sơn gốc nước để dần thay thế sơn dung môi, nhằm tối ưu hiệu suất, chi phí và tính bền vững.
- **Định hướng marketing**: Tập trung vào nội dung kỹ thuật (technical content), SEO, video demo thi công, email marketing B2B, và tổ chức hội thảo ngành.
`;

function buildSystemInstruction(): string {
    return `You are 'Chat Lavis AI', a professional and knowledgeable assistant for the industrial paint company 'Lavis Brothers Coating'.
    Your primary goal is to answer user questions based on the provided KNOWLEDGE BASE about the company's products and services.
    Your tone should be professional, helpful, and confident.
    If the knowledge base doesn't have the answer, you are allowed to use Google Search to find relevant, up-to-date information.
    Format your answers clearly and professionally using Markdown (e.g., bolding, bullet points, tables).
    Use emojis (like 🎨, 🏭, ✅) where appropriate to make the conversation engaging, but maintain a professional tone.
    If the user provides their name or phone number, extract it for potential follow-up.
    Do not make up information. If you use Google Search, you MUST cite your sources at the end of your response.
    Never mention that you are an AI or a language model. Your persona is that of a company expert.

    ---
    KNOWLEDGE BASE:
    ${KNOWLEDGE_BASE}
    ---
    `;
}

export const getBotResponse = async (
  userInput: string,
  history: Message[],
): Promise<{ responseText: string; extractedInfo: { name: string; phone: string } | null, sources: GroundingSource[] | null }> => {
  const systemInstruction = buildSystemInstruction();

  const contents = history
    .filter(msg => msg.id !== 'initial-message') // Exclude the initial welcome message
    .map(msg => ({
      role: msg.role,
      parts: msg.parts,
    }));
  contents.push({ role: Role.USER, parts: [{ text: userInput }] });

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: contents,
      config: {
        systemInstruction: systemInstruction,
        tools: [{ googleSearch: {} }],
      }
    });

    const text = response.text;
    const groundingMetadata = response.candidates?.[0]?.groundingMetadata;
    const sources: GroundingSource[] = groundingMetadata?.groundingChunks
        ?.map(chunk => chunk.web)
        .filter((web): web is GroundingSource => !!web) || [];
    
    // Simple regex for info extraction as a fallback since schema is not used.
    const nameMatch = userInput.match(/(?:tôi là|tên tôi là|tên của tôi là)\s*([A-ZÀ-Ỹ][a-zà-ỹ]+(?:\s[A-ZÀ-Ỹ][a-zà-ỹ]+)*)/i);
    const phoneMatch = userInput.match(/(\b(0|84|\+84)?\d{9}\b)/g);
    
    const extractedInfo = {
        name: nameMatch ? nameMatch[1].trim() : '',
        phone: phoneMatch ? phoneMatch[0] : '',
    };

    return { responseText: text, extractedInfo, sources };
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw new Error("Failed to get response from Gemini.");
  }
};