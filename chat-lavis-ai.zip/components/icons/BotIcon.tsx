import React from 'react';

const BotIcon: React.FC<{className?: string}> = ({ className = "w-6 h-6" }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    viewBox="0 0 24 24"
    fill="currentColor"
    stroke="none"
  >
    <path d="M12,4C7.58,4,4,7.58,4,12s3.58,8,8,8,8-3.58,8-8S16.42,4,12,4Zm3.5,9.5c-1.38,0-2.5-1.12-2.5-2.5s1.12-2.5,2.5-2.5,2.5,1.12,2.5,2.5-1.12,2.5-2.5,2.5Zm-7,0c-1.38,0-2.5-1.12-2.5-2.5s1.12-2.5,2.5-2.5,2.5,1.12,2.5,2.5S9.88,13.5,8.5,13.5Zm3.5,3c-2.33,0-4.31-1.46-5.11-3.5h10.22C16.31,15.04,14.33,16.5,12,16.5Z"/>
  </svg>
);

export default BotIcon;